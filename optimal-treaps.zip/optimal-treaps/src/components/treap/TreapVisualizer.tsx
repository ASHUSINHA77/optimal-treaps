import { motion } from "framer-motion";

interface TreapNode {
  key: number;
  priority: number;
  left?: TreapNode | null;
  right?: TreapNode | null;
  depth?: number;
}

interface Props {
  root: TreapNode;
  searchPath?: number[];
}

interface NodeLayout {
  node: TreapNode;
  x: number;
  y: number;
  parentX?: number;
  parentY?: number;
}

function computeLayout(
  node: TreapNode | null | undefined,
  x: number,
  y: number,
  spread: number,
  result: NodeLayout[],
  parentX?: number,
  parentY?: number
): { minX: number; maxX: number } {
  if (!node) return { minX: x, maxX: x };

  result.push({ node, x, y, parentX, parentY });

  const leftBounds = node.left
    ? computeLayout(node.left, x - spread, y + 80, spread * 0.55, result, x, y)
    : { minX: x, maxX: x };

  const rightBounds = node.right
    ? computeLayout(node.right, x + spread, y + 80, spread * 0.55, result, x, y)
    : { minX: x, maxX: x };

  return {
    minX: Math.min(leftBounds.minX, x),
    maxX: Math.max(rightBounds.maxX, x),
  };
}

const NODE_R = 28;

export default function TreapVisualizer({ root, searchPath = [] }: Props) {
  const nodes: NodeLayout[] = [];
  const h = root ? Math.min(treeHeight(root), 5) : 3;
  const spread = Math.max(60, 60 * Math.pow(1.7, Math.max(0, h - 2)));
  computeLayout(root, 0, NODE_R + 10, spread, nodes);

  if (!nodes.length) return null;

  const xs = nodes.map(n => n.x);
  const ys = nodes.map(n => n.y);
  const minX = Math.min(...xs) - NODE_R - 10;
  const maxX = Math.max(...xs) + NODE_R + 10;
  const minY = 0;
  const maxY = Math.max(...ys) + NODE_R + 20;
  const width = maxX - minX;
  const height = maxY - minY;

  return (
    <svg
      viewBox={`${minX} ${minY} ${width} ${height}`}
      width={width}
      height={height}
      style={{ overflow: "visible", display: "block" }}
    >
      {/* Edges */}
      {nodes.map(({ node, x, y, parentX, parentY }) =>
        parentX !== undefined && parentY !== undefined ? (
          <line
            key={`edge-${node.key}`}
            x1={parentX}
            y1={parentY}
            x2={x}
            y2={y}
            stroke="rgba(255,255,255,0.12)"
            strokeWidth={1.5}
          />
        ) : null
      )}

      {/* Nodes */}
      {nodes.map(({ node, x, y }) => {
        const inPath = searchPath.includes(node.key);
        return (
          <motion.g
            key={node.key}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            style={{ transformOrigin: `${x}px ${y}px` }}
          >
            {/* Outer glow for search path */}
            {inPath && (
              <circle cx={x} cy={y} r={NODE_R + 6} fill="rgba(34,211,238,0.18)" />
            )}

            {/* Node circle */}
            <circle
              cx={x}
              cy={y}
              r={NODE_R}
              fill={inPath ? "rgba(34,211,238,0.25)" : "rgba(255,255,255,0.05)"}
              stroke={inPath ? "#22d3ee" : "rgba(255,255,255,0.2)"}
              strokeWidth={inPath ? 2 : 1}
            />

            {/* Key (BST ordering value) */}
            <text
              x={x}
              y={y + 1}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize={14}
              fontWeight="700"
              fontFamily="'Space Mono', monospace"
              fill={inPath ? "#22d3ee" : "#f1f5f9"}
            >
              {node.key}
            </text>

            {/* Priority (heap ordering value) */}
            <text
              x={x}
              y={y + NODE_R + 11}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize={9}
              fontFamily="'Space Mono', monospace"
              fill="rgba(255,255,255,0.35)"
            >
              p:{node.priority}
            </text>
          </motion.g>
        );
      })}
    </svg>
  );
}

function treeHeight(node: TreapNode | null | undefined): number {
  if (!node) return 0;
  return 1 + Math.max(treeHeight(node.left), treeHeight(node.right));
}
