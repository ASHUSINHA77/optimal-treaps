import { useMemo, useState } from "react";
import { useGetTreap } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import TreapControls from "@/components/treap/TreapControls";
import TreapVisualizer from "@/components/treap/TreapVisualizer";
import { AlertCircle } from "lucide-react";

export default function VisualizerPage() {
  const { data: treap, isLoading, isError } = useGetTreap();
  const [searchPath, setSearchPath] = useState<number[]>([]);

  if (isError) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-destructive p-8 text-center space-y-4">
        <AlertCircle className="w-12 h-12" />
        <h2 className="text-xl font-bold">Failed to load Treap</h2>
        <p className="text-muted-foreground max-w-md">There was an error communicating with the API server. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col lg:flex-row">
      {/* Sidebar Controls */}
      <div className="w-full lg:w-80 border-r border-border bg-card p-6 overflow-y-auto shrink-0 z-10 flex flex-col gap-8 shadow-xl">
        <div>
          <h2 className="text-sm font-mono text-muted-foreground mb-4 uppercase tracking-wider">Operations</h2>
          <TreapControls onSearchComplete={(path) => setSearchPath(path)} />
        </div>

        <div className="border-t border-border pt-8">
          <h2 className="text-sm font-mono text-muted-foreground mb-4 uppercase tracking-wider">State Info</h2>
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-secondary/30 p-3 rounded-md border border-border/50">
                <div className="text-xs text-muted-foreground font-mono mb-1">Size</div>
                <div className="text-xl font-mono text-foreground">{treap?.size || 0}</div>
              </div>
              <div className="bg-secondary/30 p-3 rounded-md border border-border/50">
                <div className="text-xs text-muted-foreground font-mono mb-1">Height</div>
                <div className="text-xl font-mono text-foreground">{treap?.height || 0}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 relative bg-background overflow-hidden pattern-dots pattern-border pattern-opacity-10 pattern-size-4">
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent to-background/80 z-0"></div>
        {isLoading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-pulse flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin"></div>
              <div className="text-primary font-mono text-sm tracking-widest">LOADING STRUCTURE...</div>
            </div>
          </div>
        ) : treap?.root ? (
          <div className="absolute inset-0 overflow-auto z-10 p-8 flex items-start justify-center">
             <TreapVisualizer root={treap.root} searchPath={searchPath} />
          </div>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none p-6">
            <div className="max-w-md text-center border border-dashed border-primary/30 bg-card/50 backdrop-blur p-8 rounded-xl">
              <div className="w-12 h-12 bg-primary/10 text-primary flex items-center justify-center rounded-lg mx-auto mb-4">
                <span className="font-mono text-lg font-bold">∅</span>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">Empty Treap</h3>
              <p className="text-sm text-muted-foreground mb-6">
                A Treap is a randomized binary search tree. Each node stores a key (for BST ordering) and a random priority (for Heap ordering).
                Use the operations panel to insert some keys.
              </p>
              <div className="text-xs font-mono bg-secondary/50 p-2 rounded text-left text-muted-foreground border border-border/50">
                <span className="text-primary">Insert(key)</span> → Assigns random priority, inserts as BST, then rotates up to satisfy heap property.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
