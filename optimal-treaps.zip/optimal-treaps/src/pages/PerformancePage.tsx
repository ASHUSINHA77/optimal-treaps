import { useListPerformanceLogs, useGetPerformanceStats } from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { Activity, Clock, GitMerge, Search, Trash2 } from "lucide-react";

const OP_COLORS: Record<string, string> = {
  insert: "#22d3ee",
  delete: "#f43f5e",
  search: "#a78bfa",
};

export default function PerformancePage() {
  const { data: logs, isLoading: logsLoading } = useListPerformanceLogs({ limit: 50 });
  const { data: stats, isLoading: statsLoading } = useGetPerformanceStats();

  return (
    <div className="h-full overflow-y-auto p-8 max-w-6xl mx-auto w-full">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
        <h1 className="text-2xl font-mono font-bold text-foreground mb-1">Performance Analytics</h1>
        <p className="text-muted-foreground text-sm mb-8 font-mono">Real-time operation metrics from the Treap data structure</p>

        {/* Summary cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statsLoading ? (
            <>
              {[1,2,3,4].map(i => <div key={i} className="h-24 bg-card rounded-xl animate-pulse border border-border" />)}
            </>
          ) : (
            <>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="text-xs text-muted-foreground font-mono mb-2 uppercase tracking-wider">Total Ops</div>
                <div className="text-3xl font-mono font-bold text-foreground">{stats?.totalOps ?? 0}</div>
              </div>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="text-xs text-muted-foreground font-mono mb-2 uppercase tracking-wider flex items-center gap-1"><Clock className="w-3 h-3" />Avg Time</div>
                <div className="text-3xl font-mono font-bold text-primary">{(stats?.avgTimeMs ?? 0).toFixed(3)}<span className="text-sm text-muted-foreground ml-1">ms</span></div>
              </div>
              {stats?.byOperation?.map(op => (
                <div key={op.operation} className="bg-card border border-border rounded-xl p-4">
                  <div className="text-xs font-mono mb-2 uppercase tracking-wider" style={{ color: OP_COLORS[op.operation] || "#fff" }}>{op.operation}</div>
                  <div className="text-xl font-mono font-bold text-foreground">{op.count} <span className="text-sm text-muted-foreground">ops</span></div>
                  <div className="text-xs text-muted-foreground font-mono">{op.avgTimeMs.toFixed(3)} ms avg</div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* Chart */}
        {stats?.byOperation && stats.byOperation.length > 0 && (
          <div className="bg-card border border-border rounded-xl p-6 mb-8">
            <h2 className="text-sm font-mono text-muted-foreground uppercase tracking-wider mb-6">Avg Time by Operation (ms)</h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={stats.byOperation}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="operation" tick={{ fill: "#6b7280", fontSize: 12, fontFamily: "monospace" }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 11, fontFamily: "monospace" }} />
                <Tooltip
                  contentStyle={{ background: "#0d0d14", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontFamily: "monospace", fontSize: 12 }}
                  labelStyle={{ color: "#e5e7eb" }}
                />
                <Bar dataKey="avgTimeMs" radius={[4, 4, 0, 0]} fill="#22d3ee" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Log table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Operation Log</h2>
          </div>
          {logsLoading ? (
            <div className="p-6 space-y-3">
              {[1,2,3,4,5].map(i => <div key={i} className="h-10 bg-secondary/30 rounded animate-pulse" />)}
            </div>
          ) : !logs?.length ? (
            <div className="p-12 text-center">
              <Activity className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-30" />
              <p className="text-muted-foreground font-mono text-sm">No operations recorded yet. Perform some operations on the treap first.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm font-mono">
                <thead>
                  <tr className="border-b border-border text-muted-foreground">
                    <th className="text-left px-6 py-3 text-xs uppercase tracking-wider">Op</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Key</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Time (ms)</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Nodes</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Size</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Result</th>
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log, i) => (
                    <motion.tr
                      key={log.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.02 }}
                      data-testid={`row-log-${log.id}`}
                      className="border-b border-border/50 hover:bg-secondary/20 transition-colors"
                    >
                      <td className="px-6 py-3">
                        <span className="flex items-center gap-1.5" style={{ color: OP_COLORS[log.operation] || "#fff" }}>
                          {log.operation === "insert" && <GitMerge className="w-3.5 h-3.5" />}
                          {log.operation === "delete" && <Trash2 className="w-3.5 h-3.5" />}
                          {log.operation === "search" && <Search className="w-3.5 h-3.5" />}
                          {log.operation}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-foreground">{log.key}</td>
                      <td className="px-4 py-3 text-primary">{log.operationTimeMs.toFixed(4)}</td>
                      <td className="px-4 py-3 text-foreground">{log.nodesVisited}</td>
                      <td className="px-4 py-3 text-muted-foreground">{log.treeSize}</td>
                      <td className="px-4 py-3">
                        <span className={log.success ? "text-green-400" : "text-red-400"}>
                          {log.success ? "OK" : "FAIL"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs">
                        {format(new Date(log.createdAt), "HH:mm:ss")}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
