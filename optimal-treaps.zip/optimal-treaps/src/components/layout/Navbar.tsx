import { Link, useLocation } from "wouter";
import { Activity, GitMerge } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Visualizer", icon: GitMerge },
    { href: "/performance", label: "Performance", icon: Activity },
  ];

  return (
    <nav className="h-14 border-b border-border bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/20 flex items-center px-6 gap-6 sticky top-0 z-50">
      <div className="flex items-center gap-2 font-mono text-primary font-bold tracking-tight">
        <div className="w-6 h-6 rounded bg-primary text-primary-foreground flex items-center justify-center text-sm">
          T
        </div>
        Optimal Treaps
      </div>

      <div className="flex items-center gap-2 ml-4">
        {links.map((link) => {
          const isActive = location === link.href;
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href}>
              <div
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors cursor-pointer",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
