import { useState } from "react";
import {
  useTreapInsert, useTreapDelete, useTreapSearch, useResetTreap,
  getGetTreapQueryKey, getListPerformanceLogsQueryKey, getGetPerformanceStatsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Minus, Search, RotateCcw, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Props {
  onSearchComplete: (path: number[]) => void;
}

type Result = { type: "success" | "error" | "found" | "notfound"; message: string } | null;

export default function TreapControls({ onSearchComplete }: Props) {
  const queryClient = useQueryClient();
  const [insertKey, setInsertKey] = useState("");
  const [deleteKey, setDeleteKey] = useState("");
  const [searchKey, setSearchKey] = useState("");
  const [lastResult, setLastResult] = useState<Result>(null);

  const treapInsert = useTreapInsert();
  const treapDelete = useTreapDelete();
  const treapSearch = useTreapSearch();
  const resetTreap = useResetTreap();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getGetTreapQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListPerformanceLogsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetPerformanceStatsQueryKey() });
  };

  const handleInsert = () => {
    const key = parseInt(insertKey, 10);
    if (isNaN(key)) return;
    treapInsert.mutate({ data: { key } }, {
      onSuccess: (result) => {
        invalidate();
        setInsertKey("");
        setLastResult({ type: result.success ? "success" : "error", message: result.message || `Inserted ${key}` });
        onSearchComplete([]);
      }
    });
  };

  const handleDelete = () => {
    const key = parseInt(deleteKey, 10);
    if (isNaN(key)) return;
    treapDelete.mutate({ data: { key } }, {
      onSuccess: (result) => {
        invalidate();
        setDeleteKey("");
        setLastResult({ type: result.success ? "success" : "error", message: result.message || `Deleted ${key}` });
        onSearchComplete([]);
      }
    });
  };

  const handleSearch = () => {
    const key = parseInt(searchKey, 10);
    if (isNaN(key)) return;
    treapSearch.mutate({ data: { key } }, {
      onSuccess: (result) => {
        invalidate();
        onSearchComplete(result.searchPath);
        setLastResult({
          type: result.found ? "found" : "notfound",
          message: result.found
            ? `Found ${key} in ${result.nodesVisited} nodes (${result.operationTimeMs.toFixed(3)}ms)`
            : `Key ${key} not found (${result.nodesVisited} nodes checked)`
        });
      }
    });
  };

  const handleReset = () => {
    if (!confirm("Reset the treap? This clears all nodes.")) return;
    resetTreap.mutate(undefined, {
      onSuccess: () => {
        invalidate();
        setLastResult({ type: "success", message: "Treap cleared" });
        onSearchComplete([]);
      }
    });
  };

  const isLoading = treapInsert.isPending || treapDelete.isPending || treapSearch.isPending || resetTreap.isPending;

  return (
    <div className="space-y-5">
      {/* Insert */}
      <div>
        <label className="block text-xs text-muted-foreground font-mono mb-2 uppercase tracking-wider">Insert Key</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={insertKey}
            onChange={e => setInsertKey(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleInsert()}
            placeholder="Enter integer"
            data-testid="input-insert-key"
            className="flex-1 bg-secondary/30 border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
          />
          <button
            onClick={handleInsert}
            disabled={!insertKey || isLoading}
            data-testid="button-insert"
            className="px-3 py-2 bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-md transition-colors disabled:opacity-40 flex items-center gap-1.5 font-mono text-sm"
          >
            {treapInsert.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Delete */}
      <div>
        <label className="block text-xs text-muted-foreground font-mono mb-2 uppercase tracking-wider">Delete Key</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={deleteKey}
            onChange={e => setDeleteKey(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleDelete()}
            placeholder="Enter integer"
            data-testid="input-delete-key"
            className="flex-1 bg-secondary/30 border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
          />
          <button
            onClick={handleDelete}
            disabled={!deleteKey || isLoading}
            data-testid="button-delete"
            className="px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-md transition-colors disabled:opacity-40 flex items-center gap-1.5 font-mono text-sm"
          >
            {treapDelete.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Minus className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Search */}
      <div>
        <label className="block text-xs text-muted-foreground font-mono mb-2 uppercase tracking-wider">Search Key</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={searchKey}
            onChange={e => setSearchKey(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch()}
            placeholder="Enter integer"
            data-testid="input-search-key"
            className="flex-1 bg-secondary/30 border border-border rounded-md px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
          />
          <button
            onClick={handleSearch}
            disabled={!searchKey || isLoading}
            data-testid="button-search"
            className="px-3 py-2 bg-violet-500/10 hover:bg-violet-500/20 text-violet-400 border border-violet-500/20 rounded-md transition-colors disabled:opacity-40 flex items-center gap-1.5 font-mono text-sm"
          >
            {treapSearch.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Last result */}
      <AnimatePresence mode="wait">
        {lastResult && (
          <motion.div
            key={lastResult.message}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className={`flex items-start gap-2 p-3 rounded-md text-xs font-mono border ${
              lastResult.type === "success" || lastResult.type === "found"
                ? "bg-green-500/10 border-green-500/20 text-green-400"
                : lastResult.type === "notfound"
                ? "bg-yellow-500/10 border-yellow-500/20 text-yellow-400"
                : "bg-red-500/10 border-red-500/20 text-red-400"
            }`}
          >
            {lastResult.type === "success" || lastResult.type === "found"
              ? <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              : <XCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />}
            <span>{lastResult.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reset */}
      <button
        onClick={handleReset}
        disabled={isLoading}
        data-testid="button-reset-treap"
        className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-border hover:border-red-500/30 hover:bg-red-500/5 text-muted-foreground hover:text-red-400 rounded-md transition-colors font-mono text-xs disabled:opacity-40"
      >
        <RotateCcw className="w-3.5 h-3.5" />
        Reset Treap
      </button>
    </div>
  );
}
